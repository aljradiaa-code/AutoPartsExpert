import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.worldscan.autoparts"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.worldscan.autoparts"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("com.google.android.material:material:1.14.0")

    // Local on-device AI (GGUF models via llama.cpp Kotlin bindings).
    // Using 0.4.0 — the current release, published on Maven Central and the
    // only version whose API is actually documented (the library's README
    // always documents whichever version is newest, so older versions like
    // 0.1.2 have no public API reference and can only be reverse-engineered
    // from compiler errors, which is fragile). ai/LlamaInferenceManager.kt is
    // written against 0.4.0's documented LlamaHelper(ContentResolver,
    // CoroutineScope, MutableSharedFlow<LLMEvent>) API. See
    // https://github.com/ljcamargo/kotlinllamacpp for the reference docs.
    implementation("io.github.ljcamargo:llamacpp-kotlin:0.4.0")

    // Coroutines for background downloads and model inference
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-service:2.8.7")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.3.0")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.7.0")
}


kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}
