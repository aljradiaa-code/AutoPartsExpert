package com.worldscan.autoparts.util

import java.util.Locale

object OemNormalizer {
    /**
     * يوحّد رقم القطعة بإزالة الشرطات والمسافات والرموز وتحويل الحروف إلى Uppercase.
     * مثال: 26300-35505 -> 2630035505
     */
    fun normalize(value: String): String = value
        .uppercase(Locale.ROOT)
        .filter { it in 'A'..'Z' || it in '0'..'9' }
}
