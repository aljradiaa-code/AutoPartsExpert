package com.worldscan.autoparts.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.worldscan.autoparts.R
import com.worldscan.autoparts.databinding.ItemPartBinding
import com.worldscan.autoparts.model.Part
import java.text.DecimalFormat

class PartAdapter(
    private val onPartClick: (Part) -> Unit
) : ListAdapter<Part, PartAdapter.PartViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PartViewHolder {
        val binding = ItemPartBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PartViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PartViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class PartViewHolder(
        private val binding: ItemPartBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(part: Part) = with(binding) {
            partNumberText.text = part.partNumber
            descriptionText.text = part.partDescription.ifBlank { root.context.getString(R.string.unknown) }
            companyText.text = listOf(part.companyOrigin, part.brandCategory)
                .filter { it.isNotBlank() }
                .joinToString(" • ")
                .ifBlank { root.context.getString(R.string.unknown) }
            compatibilityText.text = part.compatibilitySummary.ifBlank {
                root.context.getString(R.string.compatibility_not_available)
            }
            priceText.text = if (part.price > 0) {
                root.context.getString(R.string.price_value, PRICE_FORMAT.format(part.price))
            } else {
                root.context.getString(R.string.price_not_available)
            }
            confidenceText.text = root.context.getString(R.string.confidence, part.confidenceScore)
            verifiedChip.text = root.context.getString(
                if (part.isVerified) R.string.verified else R.string.not_verified
            )
            verifiedChip.isChipIconVisible = part.isVerified
            root.setOnClickListener { onPartClick(part) }
        }
    }

    companion object {
        private val PRICE_FORMAT = DecimalFormat("#,##0.##")

        private object DiffCallback : DiffUtil.ItemCallback<Part>() {
            override fun areItemsTheSame(oldItem: Part, newItem: Part): Boolean = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Part, newItem: Part): Boolean = oldItem == newItem
        }
    }
}
