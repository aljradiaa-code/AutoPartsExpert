package com.worldscan.autoparts.ui

import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.worldscan.autoparts.databinding.ItemChatMessageBinding
import com.worldscan.autoparts.model.ChatMessage

class ChatAdapter(private val messages: MutableList<ChatMessage> = mutableListOf()) :
    RecyclerView.Adapter<ChatAdapter.ViewHolder>() {

    fun submit(newMessages: List<ChatMessage>) {
        messages.clear()
        messages.addAll(newMessages)
        notifyDataSetChanged()
    }

    fun addMessage(message: ChatMessage) {
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }

    fun updateLastMessage(text: String) {
        if (messages.isEmpty()) return
        messages[messages.size - 1] = messages.last().copy(text = text)
        notifyItemChanged(messages.size - 1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemChatMessageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(messages[position])
    }

    override fun getItemCount(): Int = messages.size

    inner class ViewHolder(private val binding: ItemChatMessageBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(message: ChatMessage) {
            binding.messageText.text = message.text
            val ctx = binding.root.context
            if (message.isUser) {
                binding.messageRow.gravity = Gravity.START
                binding.bubbleCard.setCardBackgroundColor(ctx.getColor(com.worldscan.autoparts.R.color.brand_primary_container))
            } else {
                binding.messageRow.gravity = Gravity.END
                binding.bubbleCard.setCardBackgroundColor(ctx.getColor(com.worldscan.autoparts.R.color.brand_surface_variant))
            }
        }
    }
}
