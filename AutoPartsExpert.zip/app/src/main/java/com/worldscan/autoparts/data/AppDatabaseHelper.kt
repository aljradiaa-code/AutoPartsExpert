package com.worldscan.autoparts.data

import android.content.ContentValues
import android.content.Context
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.worldscan.autoparts.model.Part
import com.worldscan.autoparts.util.OemNormalizer
import com.worldscan.autoparts.util.TextNormalizer
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader

class AppDatabaseHelper(private val context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    init {
        setWriteAheadLoggingEnabled(true)
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE parts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                part_number TEXT NOT NULL,
                company_origin TEXT,
                part_description TEXT,
                price REAL NOT NULL DEFAULT 0,
                part_number_normalized TEXT NOT NULL,
                brand_category TEXT,
                source_type TEXT,
                import_file_name TEXT,
                import_date TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT,
                is_verified INTEGER NOT NULL DEFAULT 0,
                confidence_score REAL NOT NULL DEFAULT 100,
                search_text_normalized TEXT NOT NULL DEFAULT ''
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE compatibility (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                part_id INTEGER NOT NULL,
                car_brand TEXT,
                car_model TEXT,
                year_from INTEGER,
                year_to INTEGER,
                engine_info TEXT,
                position TEXT,
                notes TEXT,
                search_text_normalized TEXT NOT NULL DEFAULT '',
                FOREIGN KEY(part_id) REFERENCES parts(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE search_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                query_text TEXT NOT NULL,
                query_type TEXT,
                results_count INTEGER,
                search_mode TEXT,
                duration_ms INTEGER,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """.trimIndent()
        )

        db.execSQL("CREATE INDEX idx_parts_number_normalized ON parts(part_number_normalized)")
        db.execSQL("CREATE INDEX idx_parts_search_text ON parts(search_text_normalized)")
        db.execSQL("CREATE INDEX idx_compatibility_part ON compatibility(part_id)")
        db.execSQL("CREATE INDEX idx_compatibility_brand ON compatibility(car_brand)")
        db.execSQL("CREATE INDEX idx_search_log_created ON search_log(id DESC)")

        seedDatabase(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // MVP v1. في الإصدارات القادمة تُضاف Migrations بدل حذف الجداول.
        db.execSQL("DROP TABLE IF EXISTS compatibility")
        db.execSQL("DROP TABLE IF EXISTS search_log")
        db.execSQL("DROP TABLE IF EXISTS parts")
        onCreate(db)
    }

    fun searchParts(query: String, brand: String?): List<Part> {
        val normalizedText = TextNormalizer.normalizeForSearch(query)
        val normalizedOem = OemNormalizer.normalize(query)
        val tokens = normalizedText.split(' ').filter { it.length >= 2 }.take(8)
        val looksLikeOem = normalizedOem.length >= 5 && normalizedOem.any(Char::isDigit)

        val where = mutableListOf<String>()
        val args = mutableListOf<String>()

        if (looksLikeOem) {
            where += "p.part_number_normalized LIKE ?"
            args += "$normalizedOem%"
        } else tokens.forEach { token ->
            val escaped = escapeLike(token)
            if (token.matches(Regex("\\d{4}"))) {
                where += """
                    (
                        p.search_text_normalized LIKE ? ESCAPE '\\'
                        OR EXISTS (
                            SELECT 1 FROM compatibility cs
                            WHERE cs.part_id = p.id
                            AND (
                                cs.search_text_normalized LIKE ? ESCAPE '\\'
                                OR (
                                    cs.year_from IS NOT NULL
                                    AND CAST(? AS INTEGER) >= cs.year_from
                                    AND (cs.year_to IS NULL OR CAST(? AS INTEGER) <= cs.year_to)
                                )
                            )
                        )
                    )
                """.trimIndent()
                args += "%$escaped%"
                args += "%$escaped%"
                args += token
                args += token
            } else {
                where += """
                    (
                        p.search_text_normalized LIKE ? ESCAPE '\\'
                        OR EXISTS (
                            SELECT 1 FROM compatibility cs
                            WHERE cs.part_id = p.id
                            AND cs.search_text_normalized LIKE ? ESCAPE '\\'
                        )
                    )
                """.trimIndent()
                args += "%$escaped%"
                args += "%$escaped%"
            }
        }

        if (!brand.isNullOrBlank()) {
            where += """
                EXISTS (
                    SELECT 1 FROM compatibility cb
                    WHERE cb.part_id = p.id AND cb.car_brand = ?
                )
            """.trimIndent()
            args += brand
        }

        val whereClause = if (where.isEmpty()) "1 = 1" else where.joinToString(" AND ")
        val exactNumber = normalizedOem.ifBlank { "__NO_EXACT_MATCH__" }
        val prefixNumber = if (normalizedOem.isBlank()) "__NO_PREFIX_MATCH__" else "$normalizedOem%"

        val sql = """
            SELECT
                p.id,
                p.part_number,
                p.company_origin,
                p.part_description,
                p.price,
                p.part_number_normalized,
                p.brand_category,
                p.source_type,
                p.import_file_name,
                p.is_verified,
                p.confidence_score,
                COALESCE(
                    (
                        SELECT GROUP_CONCAT(
                            TRIM(
                                COALESCE(c.car_brand, '') || ' ' ||
                                COALESCE(c.car_model, '') ||
                                CASE
                                    WHEN c.year_from IS NOT NULL AND c.year_to IS NOT NULL
                                        THEN ' ' || c.year_from || '–' || c.year_to
                                    WHEN c.year_from IS NOT NULL
                                        THEN ' من ' || c.year_from
                                    ELSE ''
                                END ||
                                CASE WHEN COALESCE(c.engine_info, '') <> ''
                                    THEN ' • ' || c.engine_info ELSE '' END ||
                                CASE WHEN COALESCE(c.position, '') <> ''
                                    THEN ' • ' || c.position ELSE '' END
                            ),
                            ' | '
                        )
                        FROM compatibility c
                        WHERE c.part_id = p.id
                    ),
                    ''
                ) AS compatibility_summary
            FROM parts p
            WHERE $whereClause
            ORDER BY
                CASE
                    WHEN p.part_number_normalized = ? THEN 0
                    WHEN p.part_number_normalized LIKE ? THEN 1
                    ELSE 2
                END,
                p.is_verified DESC,
                p.confidence_score DESC,
                p.id DESC
            LIMIT 100
        """.trimIndent()

        args += exactNumber
        args += prefixNumber

        val results = mutableListOf<Part>()
        readableDatabase.rawQuery(sql, args.toTypedArray()).use { cursor ->
            while (cursor.moveToNext()) {
                results += Part(
                    id = cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                    partNumber = cursor.getString(cursor.getColumnIndexOrThrow("part_number")),
                    companyOrigin = cursor.getString(cursor.getColumnIndexOrThrow("company_origin")) ?: "",
                    partDescription = cursor.getString(cursor.getColumnIndexOrThrow("part_description")) ?: "",
                    price = cursor.getDouble(cursor.getColumnIndexOrThrow("price")),
                    partNumberNormalized = cursor.getString(cursor.getColumnIndexOrThrow("part_number_normalized")),
                    brandCategory = cursor.getString(cursor.getColumnIndexOrThrow("brand_category")) ?: "",
                    sourceType = cursor.getString(cursor.getColumnIndexOrThrow("source_type")) ?: "",
                    importFileName = cursor.getString(cursor.getColumnIndexOrThrow("import_file_name")),
                    isVerified = cursor.getInt(cursor.getColumnIndexOrThrow("is_verified")) == 1,
                    confidenceScore = cursor.getDouble(cursor.getColumnIndexOrThrow("confidence_score")),
                    compatibilitySummary = cursor.getString(cursor.getColumnIndexOrThrow("compatibility_summary")) ?: ""
                )
            }
        }
        return results
    }

    fun logSearch(query: String, resultsCount: Int, durationMs: Long) {
        if (query.isBlank()) return
        val values = ContentValues().apply {
            put("query_text", query.trim())
            put("query_type", inferQueryType(query))
            put("results_count", resultsCount)
            put("search_mode", "local")
            put("duration_ms", durationMs)
        }
        writableDatabase.insert("search_log", null, values)
        trimSearchLog()
    }

    fun getRecentSearches(limit: Int = 6): List<String> {
        val sql = """
            SELECT query_text, MAX(id) AS latest_id
            FROM search_log
            WHERE TRIM(query_text) <> ''
            GROUP BY query_text
            ORDER BY latest_id DESC
            LIMIT ?
        """.trimIndent()
        val items = mutableListOf<String>()
        readableDatabase.rawQuery(sql, arrayOf(limit.toString())).use { cursor ->
            while (cursor.moveToNext()) items += cursor.getString(0)
        }
        return items
    }

    fun getPartCount(): Int = DatabaseUtils.longForQuery(
        readableDatabase,
        "SELECT COUNT(*) FROM parts",
        null
    ).toInt()

    private fun trimSearchLog() {
        writableDatabase.execSQL(
            "DELETE FROM search_log WHERE id NOT IN (SELECT id FROM search_log ORDER BY id DESC LIMIT 200)"
        )
    }

    private fun seedDatabase(db: SQLiteDatabase) {
        val json = context.assets.open(SEED_FILE).use { input ->
            BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
        }
        val array = JSONArray(json)

        for (index in 0 until array.length()) {
            val item = array.getJSONObject(index)
            val number = item.getString("part_number")
            val company = item.optString("company_origin")
            val description = item.optString("part_description")
            val category = item.optString("brand_category")
            val normalizedNumber = OemNormalizer.normalize(number)
            val searchText = TextNormalizer.normalizeForSearch(
                listOf(number, normalizedNumber, company, description, category).joinToString(" ")
            )

            val partValues = ContentValues().apply {
                put("part_number", number)
                put("company_origin", company)
                put("part_description", description)
                put("price", item.optDouble("price", 0.0))
                put("part_number_normalized", normalizedNumber)
                put("brand_category", category)
                put("source_type", item.optString("source_type", "demo"))
                put("import_file_name", SEED_FILE)
                put("is_verified", if (item.optBoolean("is_verified", false)) 1 else 0)
                put("confidence_score", item.optDouble("confidence_score", 80.0))
                put("search_text_normalized", searchText)
            }
            val partId = db.insertOrThrow("parts", null, partValues)

            val compatibility = item.optJSONArray("compatibility") ?: JSONArray()
            for (compatIndex in 0 until compatibility.length()) {
                val compat = compatibility.getJSONObject(compatIndex)
                val brand = compat.optString("car_brand")
                val model = compat.optString("car_model")
                val yearFrom = compat.optInt("year_from", 0).takeIf { it > 0 }
                val yearTo = compat.optInt("year_to", 0).takeIf { it > 0 }
                val engine = compat.optString("engine_info")
                val position = compat.optString("position")
                val notes = compat.optString("notes")
                val compatibilitySearch = TextNormalizer.normalizeForSearch(
                    listOf(brand, model, yearFrom, yearTo, engine, position, notes).joinToString(" ")
                )

                val compatValues = ContentValues().apply {
                    put("part_id", partId)
                    put("car_brand", brand)
                    put("car_model", model)
                    yearFrom?.let { put("year_from", it) }
                    yearTo?.let { put("year_to", it) }
                    put("engine_info", engine)
                    put("position", position)
                    put("notes", notes)
                    put("search_text_normalized", compatibilitySearch)
                }
                db.insertOrThrow("compatibility", null, compatValues)
            }
        }
    }

    private fun inferQueryType(query: String): String {
        val normalized = OemNormalizer.normalize(query)
        return when {
            normalized.length >= 6 && normalized.any(Char::isDigit) -> "OEM"
            query.any(Char::isDigit) -> "ModelOrYear"
            else -> "Description"
        }
    }

    private fun escapeLike(value: String): String = value
        .replace("\\", "\\\\")
        .replace("%", "\\%")
        .replace("_", "\\_")

    companion object {
        private const val DATABASE_NAME = "auto_parts.db"
        private const val DATABASE_VERSION = 1
        private const val SEED_FILE = "parts_seed.json"
    }
}
