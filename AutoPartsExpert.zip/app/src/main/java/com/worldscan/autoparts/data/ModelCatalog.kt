package com.worldscan.autoparts.data

/**
 * Curated list of small, quantized GGUF models that are realistic to run fully
 * on a mid-range phone CPU with llama.cpp, and small enough to download over
 * a mobile connection. Add more entries here as needed — everything else
 * (download screen, resume logic, chat) reads from this list.
 */
object ModelCatalog {
    val models: List<ModelInfo> = listOf(
        ModelInfo(
            id = "smollm2-360m-instruct-q8",
            displayName = "SmolLM2 360M Instruct (Q8)",
            description = "أصغر وأسرع نموذج، مناسب للأجهزة محدودة الإمكانيات أو للتجربة الأولى.",
            fileName = "smollm2-360m-instruct-q8_0.gguf",
            downloadUrl = "https://huggingface.co/HuggingFaceTB/SmolLM2-360M-Instruct-GGUF/resolve/main/smollm2-360m-instruct-q8_0.gguf",
            sizeBytes = 386_000_000L
        ),
        ModelInfo(
            id = "qwen2.5-0.5b-instruct-q4",
            displayName = "Qwen2.5 0.5B Instruct (Q4_K_M)",
            description = "توازن أفضل بين الجودة والحجم، يعطي إجابات أدق في المناقشة.",
            fileName = "qwen2.5-0.5b-instruct-q4_k_m.gguf",
            downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf",
            sizeBytes = 491_000_000L
        )
    )

    fun byId(id: String): ModelInfo? = models.firstOrNull { it.id == id }
}
