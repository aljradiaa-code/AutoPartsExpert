package com.worldscan.autoparts.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.worldscan.autoparts.R
import com.worldscan.autoparts.databinding.DialogPartDetailsBinding
import com.worldscan.autoparts.model.Part
import java.text.DecimalFormat

class PartDetailsBottomSheet : BottomSheetDialogFragment() {
    private var _binding: DialogPartDetailsBinding? = null
    private val binding get() = requireNotNull(_binding)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogPartDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val args = requireArguments()
        val partNumber = args.getString(ARG_NUMBER).orEmpty()

        binding.partNumberValue.text = partNumber
        binding.descriptionValue.text = args.getString(ARG_DESCRIPTION).orEmpty().ifBlank {
            getString(R.string.unknown)
        }
        binding.companyValue.text = args.getString(ARG_COMPANY).orEmpty().ifBlank {
            getString(R.string.unknown)
        }
        binding.categoryValue.text = args.getString(ARG_CATEGORY).orEmpty().ifBlank {
            getString(R.string.unknown)
        }
        binding.compatibilityValue.text = args.getString(ARG_COMPATIBILITY).orEmpty().ifBlank {
            getString(R.string.compatibility_not_available)
        }
        val price = args.getDouble(ARG_PRICE)
        binding.priceValue.text = if (price > 0) PRICE_FORMAT.format(price) else getString(R.string.price_not_available)
        binding.sourceValue.text = args.getString(ARG_SOURCE).orEmpty().ifBlank { getString(R.string.unknown) }
        binding.confidenceValue.text = getString(R.string.confidence, args.getDouble(ARG_CONFIDENCE))

        binding.copyButton.setOnClickListener {
            val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText(getString(R.string.part_number), partNumber))
            Toast.makeText(requireContext(), R.string.copied, Toast.LENGTH_SHORT).show()
        }
        binding.closeButton.setOnClickListener { dismiss() }
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }

    companion object {
        private const val ARG_NUMBER = "number"
        private const val ARG_DESCRIPTION = "description"
        private const val ARG_COMPANY = "company"
        private const val ARG_CATEGORY = "category"
        private const val ARG_COMPATIBILITY = "compatibility"
        private const val ARG_PRICE = "price"
        private const val ARG_SOURCE = "source"
        private const val ARG_CONFIDENCE = "confidence"
        private val PRICE_FORMAT = DecimalFormat("#,##0.##")

        fun newInstance(part: Part): PartDetailsBottomSheet {
            return PartDetailsBottomSheet().apply {
                arguments = Bundle().apply {
                    putString(ARG_NUMBER, part.partNumber)
                    putString(ARG_DESCRIPTION, part.partDescription)
                    putString(ARG_COMPANY, part.companyOrigin)
                    putString(ARG_CATEGORY, part.brandCategory)
                    putString(ARG_COMPATIBILITY, part.compatibilitySummary)
                    putDouble(ARG_PRICE, part.price)
                    putString(
                        ARG_SOURCE,
                        listOf(part.sourceType, part.importFileName.orEmpty())
                            .filter { it.isNotBlank() }
                            .joinToString(" • ")
                    )
                    putDouble(ARG_CONFIDENCE, part.confidenceScore)
                }
            }
        }
    }
}
