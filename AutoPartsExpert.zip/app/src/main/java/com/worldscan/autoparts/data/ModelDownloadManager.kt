package com.worldscan.autoparts.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL

/**
 * Handles downloading GGUF models to app-private storage with resume support.
 *
 * Resume works in two layers:
 *  - While the process is alive: pausing cancels the coroutine but keeps the
 *    partially written ".part" file on disk.
 *  - After the process/app was killed: on next launch we detect the ".part"
 *    file's length and simply continue requesting bytes from that offset
 *    using an HTTP Range request, so an interrupted download is never lost.
 */
object ModelDownloadManager {

    private const val PART_SUFFIX = ".part"
    private const val BUFFER_SIZE = 64 * 1024
    private const val PROGRESS_UPDATE_INTERVAL_MS = 200L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = mutableMapOf<String, Job>()

    private val _states = MutableStateFlow<Map<String, ModelDownloadState>>(emptyMap())
    val states: StateFlow<Map<String, ModelDownloadState>> = _states

    fun modelsDir(context: Context): File =
        File(context.filesDir, "ai_models").apply { if (!exists()) mkdirs() }

    fun targetFile(context: Context, model: ModelInfo): File =
        File(modelsDir(context), model.fileName)

    private fun partFile(context: Context, model: ModelInfo): File =
        File(modelsDir(context), model.fileName + PART_SUFFIX)

    /** Reads the current status straight from disk — safe to call right after process start. */
    fun statusOf(context: Context, model: ModelInfo): ModelDownloadState {
        _states.value[model.id]?.let { cached ->
            if (cached.status == ModelStatus.DOWNLOADING) return cached
        }
        val target = targetFile(context, model)
        val part = partFile(context, model)
        val state = when {
            target.exists() && target.length() >= model.sizeBytes -> ModelDownloadState(
                model.id, ModelStatus.DOWNLOADED, target.length(), target.length()
            )
            part.exists() && part.length() > 0L -> ModelDownloadState(
                model.id, ModelStatus.PAUSED, part.length(), model.sizeBytes
            )
            else -> ModelDownloadState(model.id, ModelStatus.NOT_DOWNLOADED, 0L, model.sizeBytes)
        }
        _states.update { it + (model.id to state) }
        return state
    }

    fun isAnyModelDownloaded(context: Context): Boolean =
        ModelCatalog.models.any { statusOf(context, it).status == ModelStatus.DOWNLOADED }

    fun firstDownloadedModel(context: Context): ModelInfo? =
        ModelCatalog.models.firstOrNull { statusOf(context, it).status == ModelStatus.DOWNLOADED }

    fun hasActiveDownload(): Boolean = _states.value.values.any { it.status == ModelStatus.DOWNLOADING }

    fun start(context: Context, model: ModelInfo) {
        if (jobs[model.id]?.isActive == true) return
        val appContext = context.applicationContext
        setState(model.id) { it.copy(status = ModelStatus.DOWNLOADING, error = null) }
        jobs[model.id] = scope.launch {
            try {
                downloadInternal(appContext, model)
            } catch (io: IOException) {
                setState(model.id) { it.copy(status = ModelStatus.ERROR, error = io.message) }
            } catch (t: Throwable) {
                // Cancellation from pause()/cancel() is expected and already reflected in state.
                if (t !is kotlinx.coroutines.CancellationException) {
                    setState(model.id) { it.copy(status = ModelStatus.ERROR, error = t.message) }
                }
            }
        }
    }

    /** Stops the transfer but keeps the partial file so it can be resumed later. */
    fun pause(model: ModelInfo) {
        setState(model.id) { it.copy(status = ModelStatus.PAUSED) }
        jobs[model.id]?.cancel()
    }

    /** Stops the transfer and deletes any partial data. */
    fun cancelAndDelete(context: Context, model: ModelInfo) {
        jobs[model.id]?.cancel()
        targetFile(context, model).delete()
        partFile(context, model).delete()
        setState(model.id) { ModelDownloadState(model.id, ModelStatus.NOT_DOWNLOADED, 0L, model.sizeBytes) }
    }

    private fun setState(modelId: String, transform: (ModelDownloadState) -> ModelDownloadState) {
        _states.update { current ->
            val existing = current[modelId] ?: ModelDownloadState(modelId, ModelStatus.NOT_DOWNLOADED)
            current + (modelId to transform(existing))
        }
    }

    private suspend fun downloadInternal(context: Context, model: ModelInfo) {
        val target = targetFile(context, model)
        val part = partFile(context, model)

        if (target.exists() && target.length() >= model.sizeBytes) {
            setState(model.id) { it.copy(status = ModelStatus.DOWNLOADED, downloadedBytes = target.length(), totalBytes = target.length()) }
            return
        }

        var downloaded = if (part.exists()) part.length() else 0L
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(model.downloadUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20_000
                readTimeout = 20_000
                instanceFollowRedirects = true
                if (downloaded > 0) setRequestProperty("Range", "bytes=$downloaded-")
                connect()
            }

            val responseCode = connection.responseCode
            if (responseCode !in 200..299) {
                throw IOException("HTTP $responseCode")
            }

            // Server may ignore the Range header (200 instead of 206) — restart from zero.
            val resumed = responseCode == HttpURLConnection.HTTP_PARTIAL
            if (!resumed) {
                downloaded = 0L
            }
            val remoteLength = connection.contentLengthLong
            val totalBytes = when {
                remoteLength <= 0 -> model.sizeBytes
                resumed -> downloaded + remoteLength
                else -> remoteLength
            }

            setState(model.id) { it.copy(downloadedBytes = downloaded, totalBytes = totalBytes) }

            RandomAccessFile(part, "rw").use { raf ->
                if (!resumed) raf.setLength(0)
                raf.seek(downloaded)
                connection.inputStream.use { input ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    var lastUpdate = 0L
                    while (currentCoroutineContext().isActive) {
                        val read = input.read(buffer)
                        if (read == -1) break
                        raf.write(buffer, 0, read)
                        downloaded += read
                        val now = System.currentTimeMillis()
                        if (now - lastUpdate > PROGRESS_UPDATE_INTERVAL_MS) {
                            lastUpdate = now
                            setState(model.id) { it.copy(downloadedBytes = downloaded, totalBytes = totalBytes) }
                        }
                    }
                }
            }

            if (!currentCoroutineContext().isActive) {
                // Paused or cancelled mid-flight — keep the .part file for a later resume.
                setState(model.id) { it.copy(downloadedBytes = downloaded) }
                return
            }

            if (!part.renameTo(target)) {
                part.copyTo(target, overwrite = true)
                part.delete()
            }
            setState(model.id) {
                it.copy(status = ModelStatus.DOWNLOADED, downloadedBytes = target.length(), totalBytes = target.length())
            }
        } finally {
            connection?.disconnect()
        }
    }
}
