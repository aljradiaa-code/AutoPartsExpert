package com.worldscan.autoparts.model

data class Part(
    val id: Long,
    val partNumber: String,
    val companyOrigin: String,
    val partDescription: String,
    val price: Double,
    val partNumberNormalized: String,
    val brandCategory: String,
    val sourceType: String,
    val importFileName: String?,
    val isVerified: Boolean,
    val confidenceScore: Double,
    val compatibilitySummary: String
)
