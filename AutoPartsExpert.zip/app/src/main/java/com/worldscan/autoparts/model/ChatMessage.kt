package com.worldscan.autoparts.model

data class ChatMessage(
    val text: String,
    val isUser: Boolean
)
