package com.worldscan.autoparts.util

import java.util.Locale

object TextNormalizer {
    private val arabicDiacritics = Regex("[\\u0610-\\u061A\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]")
    private val punctuation = Regex("[^\\p{L}\\p{N}]+")
    private val spaces = Regex("\\s+")

    /**
     * تطبيع خفيف للبحث العربي والإنجليزي.
     * لا يغيّر النص المعروض، وإنما يُستخدم في حقل بحث داخلي فقط.
     */
    fun normalizeForSearch(value: String): String {
        return value
            .lowercase(Locale.ROOT)
            .replace(arabicDiacritics, "")
            .replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ٱ', 'ا')
            .replace('ى', 'ي')
            .replace('ؤ', 'و')
            .replace('ئ', 'ي')
            .replace('ة', 'ه')
            .replace(punctuation, " ")
            .replace(spaces, " ")
            .trim()
    }
}
