package com.worldscan.autoparts.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.worldscan.autoparts.R
import com.worldscan.autoparts.data.ModelCatalog
import com.worldscan.autoparts.data.ModelDownloadManager
import com.worldscan.autoparts.data.ModelStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Keeps model downloads running (and visible) even if the user leaves the app
 * or the screen turns off. All actual download/resume logic lives in
 * [ModelDownloadManager]; this service just supervises it and shows progress.
 */
class ModelDownloadService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main)
    private var watcherJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val modelId = intent.getStringExtra(EXTRA_MODEL_ID)
                val model = ModelCatalog.byId(modelId ?: "")
                startForeground(NOTIFICATION_ID, buildNotification(0, 0))
                if (model != null) ModelDownloadManager.start(applicationContext, model)
                watchProgress()
            }
            ACTION_PAUSE -> {
                val model = ModelCatalog.byId(intent.getStringExtra(EXTRA_MODEL_ID) ?: "")
                model?.let { ModelDownloadManager.pause(it) }
                stopIfIdle()
            }
            ACTION_CANCEL -> {
                val model = ModelCatalog.byId(intent.getStringExtra(EXTRA_MODEL_ID) ?: "")
                model?.let { ModelDownloadManager.cancelAndDelete(applicationContext, it) }
                stopIfIdle()
            }
        }
        return START_NOT_STICKY
    }

    private fun watchProgress() {
        watcherJob?.cancel()
        watcherJob = serviceScope.launch {
            ModelDownloadManager.states.collect { states ->
                val downloading = states.values.filter { it.status == ModelStatus.DOWNLOADING }
                if (downloading.isEmpty()) {
                    stopIfIdle()
                } else {
                    val downloaded = downloading.sumOf { it.downloadedBytes }
                    val total = downloading.sumOf { it.totalBytes }.coerceAtLeast(1L)
                    val manager = getSystemService(NotificationManager::class.java)
                    manager?.notify(NOTIFICATION_ID, buildNotification(downloaded, total))
                }
            }
        }
    }

    private fun stopIfIdle() {
        if (!ModelDownloadManager.hasActiveDownload()) {
            watcherJob?.cancel()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun buildNotification(downloaded: Long, total: Long): android.app.Notification {
        val percent = if (total > 0) ((downloaded * 100) / total).toInt() else 0
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_downloading_title))
            .setContentText("$percent%")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setProgress(100, percent, total <= 0L)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_downloads),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        watcherJob?.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "model_downloads"
        private const val NOTIFICATION_ID = 42
        const val ACTION_START = "com.worldscan.autoparts.action.START_DOWNLOAD"
        const val ACTION_PAUSE = "com.worldscan.autoparts.action.PAUSE_DOWNLOAD"
        const val ACTION_CANCEL = "com.worldscan.autoparts.action.CANCEL_DOWNLOAD"
        const val EXTRA_MODEL_ID = "model_id"

        fun start(context: Context, modelId: String) {
            val intent = Intent(context, ModelDownloadService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_MODEL_ID, modelId)
            context.startForegroundService(intent)
        }

        fun pause(context: Context, modelId: String) {
            val intent = Intent(context, ModelDownloadService::class.java)
                .setAction(ACTION_PAUSE)
                .putExtra(EXTRA_MODEL_ID, modelId)
            context.startService(intent)
        }

        fun cancel(context: Context, modelId: String) {
            val intent = Intent(context, ModelDownloadService::class.java)
                .setAction(ACTION_CANCEL)
                .putExtra(EXTRA_MODEL_ID, modelId)
            context.startService(intent)
        }
    }
}
