package com.worldscan.autoparts

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.google.android.material.snackbar.Snackbar
import com.worldscan.autoparts.data.AppDatabaseHelper
import com.worldscan.autoparts.data.PartRepository
import com.worldscan.autoparts.databinding.ActivityMainBinding
import com.worldscan.autoparts.model.Part
import com.worldscan.autoparts.ui.ChatActivity
import com.worldscan.autoparts.ui.ModelsActivity
import com.worldscan.autoparts.ui.PartAdapter
import com.worldscan.autoparts.ui.PartDetailsBottomSheet
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: PartRepository
    private lateinit var adapter: PartAdapter

    private val debounceHandler = Handler(Looper.getMainLooper())
    private var debounceRunnable: Runnable? = null
    private var selectedBrand: String? = null
    private var currentRequestId = 0L
    private var lastResults: List<Part> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        configureInsets()

        repository = PartRepository(AppDatabaseHelper(applicationContext))
        adapter = PartAdapter { part ->
            PartDetailsBottomSheet.newInstance(part)
                .show(supportFragmentManager, "part_details")
        }

        binding.resultsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.resultsRecyclerView.adapter = adapter
        binding.resultsRecyclerView.setHasFixedSize(false)

        setupSearch()
        setupBrandFilters()
        setupToolbarMenu()
        loadMetadata()
        performSearch(immediate = true)
    }

    private fun setupToolbarMenu() {
        binding.toolbar.inflateMenu(R.menu.menu_main)
        binding.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menuModels -> {
                    startActivity(Intent(this, ModelsActivity::class.java))
                    true
                }
                R.id.menuChat -> {
                    openChat()
                    true
                }
                else -> false
            }
        }
    }

    private fun openChat() {
        val query = binding.searchEditText.text?.toString().orEmpty().trim()
        val resultsJson = JSONArray().apply {
            lastResults.take(MAX_CHAT_CONTEXT_RESULTS).forEach { part ->
                put(
                    JSONObject().apply {
                        put("partNumber", part.partNumber)
                        put("description", part.partDescription)
                        put("brand", part.brandCategory)
                    }
                )
            }
        }
        val intent = Intent(this, ChatActivity::class.java)
            .putExtra(ChatActivity.EXTRA_QUERY, query)
            .putExtra(ChatActivity.EXTRA_RESULTS_JSON, resultsJson.toString())
        startActivity(intent)
    }

    private fun configureInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(top = systemBars.top, bottom = systemBars.bottom)
            insets
        }
    }

    private fun setupSearch() {
        binding.searchEditText.addTextChangedListener(SimpleTextWatcher {
            performSearch(immediate = false)
        })

        binding.searchEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch(immediate = true)
                true
            } else {
                false
            }
        }
    }

    private fun setupBrandFilters() {
        binding.brandChipGroup.setOnCheckedStateChangeListener { _, checkedIds ->
            selectedBrand = when (checkedIds.firstOrNull()) {
                R.id.chipHyundai -> BRAND_HYUNDAI
                R.id.chipKia -> BRAND_KIA
                R.id.chipToyota -> BRAND_TOYOTA
                else -> null
            }
            performSearch(immediate = true)
        }
    }

    private fun performSearch(immediate: Boolean) {
        debounceRunnable?.let(debounceHandler::removeCallbacks)
        val runnable = Runnable { executeSearch() }
        debounceRunnable = runnable
        if (immediate) runnable.run() else debounceHandler.postDelayed(runnable, SEARCH_DEBOUNCE_MS)
    }

    private fun executeSearch() {
        val query = binding.searchEditText.text?.toString().orEmpty().trim()
        val requestId = ++currentRequestId
        showLoading(true)

        repository.search(query, selectedBrand) { result ->
            if (requestId != currentRequestId || isFinishing || isDestroyed) return@search
            showLoading(false)

            result.onSuccess { searchResult ->
                lastResults = searchResult.parts
                adapter.submitList(searchResult.parts)
                binding.resultCountText.text = getString(R.string.results_count, searchResult.parts.size)
                updateEmptyState(query, searchResult.parts.isEmpty())
                if (query.isNotBlank()) loadMetadata()
            }.onFailure {
                adapter.submitList(emptyList())
                updateEmptyState(query, true)
                Snackbar.make(binding.root, R.string.search_error, Snackbar.LENGTH_LONG).show()
            }
        }
    }

    private fun updateEmptyState(query: String, isEmpty: Boolean) {
        binding.emptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.resultsRecyclerView.visibility = if (isEmpty) View.GONE else View.VISIBLE

        if (isEmpty) {
            if (query.isBlank() && selectedBrand == null) {
                binding.emptyTitle.setText(R.string.start_search_title)
                binding.emptyBody.setText(R.string.start_search_body)
            } else {
                binding.emptyTitle.setText(R.string.no_results_title)
                binding.emptyBody.setText(R.string.no_results_body)
            }
        }
    }

    private fun showLoading(show: Boolean) {
        binding.progressIndicator.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun loadMetadata() {
        repository.loadMetadata { count, recent ->
            if (isFinishing || isDestroyed) return@loadMetadata
            binding.databaseCountText.text = getString(R.string.database_count, count)
            renderRecentSearches(recent)
        }
    }

    private fun renderRecentSearches(items: List<String>) {
        binding.recentChipGroup.removeAllViews()
        binding.recentSection.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE

        items.forEach { query ->
            val chip = Chip(this).apply {
                text = query
                isCheckable = false
                isClickable = true
                setOnClickListener {
                    binding.searchEditText.setText(query)
                    binding.searchEditText.setSelection(query.length)
                    performSearch(immediate = true)
                }
            }
            binding.recentChipGroup.addView(chip)
        }
    }

    override fun onDestroy() {
        debounceRunnable?.let(debounceHandler::removeCallbacks)
        repository.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val SEARCH_DEBOUNCE_MS = 350L
        private const val MAX_CHAT_CONTEXT_RESULTS = 8
        private const val BRAND_HYUNDAI = "هيونداي"
        private const val BRAND_KIA = "كيا"
        private const val BRAND_TOYOTA = "تويوتا"
    }
}
