package com.worldscan.autoparts.data

/**
 * Describes one downloadable, on-device GGUF AI model.
 *
 * [sizeBytes] is the known file size on the server and is used both to show a
 * human readable size before downloading, and to detect a fully downloaded file.
 */
data class ModelInfo(
    val id: String,
    val displayName: String,
    val description: String,
    val fileName: String,
    val downloadUrl: String,
    val sizeBytes: Long
)

enum class ModelStatus {
    NOT_DOWNLOADED,
    DOWNLOADING,
    PAUSED,
    DOWNLOADED,
    ERROR
}

data class ModelDownloadState(
    val modelId: String,
    val status: ModelStatus,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    val error: String? = null
)
