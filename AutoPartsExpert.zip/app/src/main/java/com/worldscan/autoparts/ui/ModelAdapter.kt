package com.worldscan.autoparts.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.worldscan.autoparts.R
import com.worldscan.autoparts.data.ModelDownloadState
import com.worldscan.autoparts.data.ModelInfo
import com.worldscan.autoparts.data.ModelStatus
import com.worldscan.autoparts.databinding.ItemModelBinding
import com.worldscan.autoparts.util.FormatUtils

class ModelAdapter(
    private val models: List<ModelInfo>,
    private val onDownload: (ModelInfo) -> Unit,
    private val onPause: (ModelInfo) -> Unit,
    private val onResume: (ModelInfo) -> Unit,
    private val onDelete: (ModelInfo) -> Unit
) : RecyclerView.Adapter<ModelAdapter.ViewHolder>() {

    private val states = mutableMapOf<String, ModelDownloadState>()

    fun updateState(state: ModelDownloadState) {
        states[state.modelId] = state
        val index = models.indexOfFirst { it.id == state.modelId }
        if (index >= 0) notifyItemChanged(index)
    }

    fun seedState(state: ModelDownloadState) {
        states[state.modelId] = state
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemModelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(models[position], states[models[position].id])
    }

    override fun getItemCount(): Int = models.size

    inner class ViewHolder(private val binding: ItemModelBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(model: ModelInfo, state: ModelDownloadState?) {
            val ctx = binding.root.context
            binding.modelName.text = model.displayName
            binding.modelDescription.text = model.description
            binding.modelSize.text = ctx.getString(R.string.model_size, FormatUtils.bytesToReadable(model.sizeBytes))

            val status = state?.status ?: ModelStatus.NOT_DOWNLOADED
            binding.deleteButton.visibility = if (status == ModelStatus.NOT_DOWNLOADED) android.view.View.GONE else android.view.View.VISIBLE
            binding.deleteButton.setOnClickListener { onDelete(model) }

            val defaultStatusColor = binding.modelDescription.currentTextColor
            binding.modelStatus.setTextColor(defaultStatusColor)

            when (status) {
                ModelStatus.NOT_DOWNLOADED -> {
                    binding.modelStatus.text = ctx.getString(R.string.model_status_not_downloaded)
                    binding.modelProgress.visibility = android.view.View.GONE
                    binding.primaryActionButton.text = ctx.getString(R.string.action_download)
                    binding.primaryActionButton.setIconResource(R.drawable.ic_download)
                    binding.primaryActionButton.setOnClickListener { onDownload(model) }
                }
                ModelStatus.DOWNLOADING -> {
                    binding.modelStatus.text = ctx.getString(R.string.model_status_downloading)
                    binding.modelProgress.visibility = android.view.View.VISIBLE
                    val total = (state?.totalBytes ?: model.sizeBytes).coerceAtLeast(1L)
                    val downloaded = state?.downloadedBytes ?: 0L
                    binding.modelProgress.isIndeterminate = false
                    binding.modelProgress.progress = ((downloaded * 100) / total).toInt().coerceIn(0, 100)
                    binding.primaryActionButton.text = ctx.getString(R.string.action_pause)
                    binding.primaryActionButton.setIconResource(R.drawable.ic_pause)
                    binding.primaryActionButton.setOnClickListener { onPause(model) }
                }
                ModelStatus.PAUSED -> {
                    binding.modelStatus.text = ctx.getString(R.string.model_status_paused)
                    binding.modelProgress.visibility = android.view.View.VISIBLE
                    val total = (state?.totalBytes ?: model.sizeBytes).coerceAtLeast(1L)
                    val downloaded = state?.downloadedBytes ?: 0L
                    binding.modelProgress.isIndeterminate = false
                    binding.modelProgress.progress = ((downloaded * 100) / total).toInt().coerceIn(0, 100)
                    binding.primaryActionButton.text = ctx.getString(R.string.action_resume)
                    binding.primaryActionButton.setIconResource(R.drawable.ic_download)
                    binding.primaryActionButton.setOnClickListener { onResume(model) }
                }
                ModelStatus.DOWNLOADED -> {
                    binding.modelStatus.text = ctx.getString(R.string.model_status_downloaded)
                    binding.modelStatus.setTextColor(ctx.getColor(R.color.success))
                    binding.modelProgress.visibility = android.view.View.GONE
                    binding.primaryActionButton.text = ctx.getString(R.string.action_delete)
                    binding.primaryActionButton.setIconResource(R.drawable.ic_delete)
                    binding.primaryActionButton.setOnClickListener { onDelete(model) }
                }
                ModelStatus.ERROR -> {
                    binding.modelStatus.text = ctx.getString(R.string.model_status_error)
                    binding.modelStatus.setTextColor(ctx.getColor(R.color.warning))
                    binding.modelProgress.visibility = android.view.View.GONE
                    binding.primaryActionButton.text = ctx.getString(R.string.action_retry)
                    binding.primaryActionButton.setIconResource(R.drawable.ic_download)
                    binding.primaryActionButton.setOnClickListener { onResume(model) }
                }
            }
        }
    }
}
