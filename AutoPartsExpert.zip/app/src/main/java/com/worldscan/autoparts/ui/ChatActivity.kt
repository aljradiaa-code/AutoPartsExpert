package com.worldscan.autoparts.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.worldscan.autoparts.R
import com.worldscan.autoparts.ai.LlamaInferenceManager
import com.worldscan.autoparts.data.ModelDownloadManager
import com.worldscan.autoparts.databinding.ActivityChatBinding
import com.worldscan.autoparts.model.ChatMessage
import kotlinx.coroutines.launch
import org.json.JSONArray

class ChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatBinding
    private lateinit var adapter: ChatAdapter
    private var inference: LlamaInferenceManager? = null
    private var contextSummary: String = ""
    private var sending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = ChatAdapter()
        binding.chatRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.chatRecyclerView.adapter = adapter

        contextSummary = buildContextSummary()
        binding.goDownloadButton.setOnClickListener {
            startActivity(Intent(this, ModelsActivity::class.java))
        }
        binding.sendButton.setOnClickListener { onSend() }

        setupModel()
    }

    private fun buildContextSummary(): String {
        val query = intent.getStringExtra(EXTRA_QUERY).orEmpty()
        val resultsJson = intent.getStringExtra(EXTRA_RESULTS_JSON)
        if (resultsJson.isNullOrBlank()) return getString(R.string.chat_no_results_context)

        val array = runCatching { JSONArray(resultsJson) }.getOrNull() ?: return getString(R.string.chat_no_results_context)
        if (array.length() == 0) return getString(R.string.chat_no_results_context)

        val lines = StringBuilder(getString(R.string.chat_context_intro, query)).append('\n')
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            lines.append("- ")
                .append(obj.optString("partNumber"))
                .append(" | ")
                .append(obj.optString("description"))
                .append(" | ")
                .append(obj.optString("brand"))
                .append('\n')
        }
        return lines.toString()
    }

    private fun setupModel() {
        val model = ModelDownloadManager.firstDownloadedModel(applicationContext)
        if (model == null) {
            binding.noModelState.visibility = View.VISIBLE
            binding.chatRecyclerView.visibility = View.GONE
            return
        }

        binding.noModelState.visibility = View.GONE
        binding.chatRecyclerView.visibility = View.VISIBLE
        binding.statusText.visibility = View.VISIBLE
        binding.statusText.text = getString(R.string.chat_loading_model)
        binding.sendButton.isEnabled = false

        lifecycleScope.launch {
            val manager = LlamaInferenceManager(applicationContext)
            inference = manager
            runCatching { manager.loadModel(model) }
                .onSuccess {
                    binding.statusText.text = getString(R.string.chat_model_ready)
                    binding.statusText.visibility = View.GONE
                    binding.sendButton.isEnabled = true
                }
                .onFailure {
                    binding.statusText.text = getString(R.string.chat_error)
                }
        }
    }

    private fun onSend() {
        if (sending) return
        val text = binding.messageEditText.text?.toString()?.trim().orEmpty()
        if (text.isBlank()) return
        val engine = inference ?: return

        binding.messageEditText.setText("")
        adapter.addMessage(ChatMessage(text = text, isUser = true))
        adapter.addMessage(ChatMessage(text = getString(R.string.chat_thinking), isUser = false))
        binding.chatRecyclerView.scrollToPosition(adapter.itemCount - 1)
        binding.thinkingIndicator.visibility = View.VISIBLE
        sending = true

        val prompt = buildPrompt(text)

        lifecycleScope.launch {
            runCatching {
                engine.ask(prompt) { partial ->
                    adapter.updateLastMessage(partial)
                    binding.chatRecyclerView.scrollToPosition(adapter.itemCount - 1)
                }
            }.onFailure {
                adapter.updateLastMessage(getString(R.string.chat_error))
            }
            binding.thinkingIndicator.visibility = View.GONE
            sending = false
        }
    }

    private fun buildPrompt(userMessage: String): String {
        return buildString {
            append("أنت مساعد ذكي متخصص في قطع غيار السيارات، تجيب باللغة العربية بإيجاز ووضوح.\n")
            append(contextSummary)
            append('\n')
            append("سؤال المستخدم: ")
            append(userMessage)
        }
    }

    override fun onDestroy() {
        inference?.release()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_QUERY = "extra_query"
        const val EXTRA_RESULTS_JSON = "extra_results_json"
    }
}
