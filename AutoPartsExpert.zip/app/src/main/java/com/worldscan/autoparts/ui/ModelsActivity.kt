package com.worldscan.autoparts.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.worldscan.autoparts.data.ModelCatalog
import com.worldscan.autoparts.data.ModelDownloadManager
import com.worldscan.autoparts.data.ModelInfo
import com.worldscan.autoparts.databinding.ActivityModelsBinding
import com.worldscan.autoparts.service.ModelDownloadService
import kotlinx.coroutines.launch

class ModelsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityModelsBinding
    private lateinit var adapter: ModelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityModelsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = ModelAdapter(
            models = ModelCatalog.models,
            onDownload = { start(it) },
            onPause = { pause(it) },
            onResume = { start(it) },
            onDelete = { delete(it) }
        )
        binding.modelsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.modelsRecyclerView.adapter = adapter

        // Seed initial state straight from disk so paused/completed downloads
        // show correctly even after the app process was restarted.
        ModelCatalog.models.forEach { model ->
            adapter.seedState(ModelDownloadManager.statusOf(applicationContext, model))
        }
        adapter.notifyDataSetChanged()

        lifecycleScope.launch {
            ModelDownloadManager.states.collect { states ->
                states.values.forEach { adapter.updateState(it) }
            }
        }
    }

    private fun start(model: ModelInfo) {
        ModelDownloadService.start(this, model.id)
    }

    private fun pause(model: ModelInfo) {
        ModelDownloadService.pause(this, model.id)
    }

    private fun delete(model: ModelInfo) {
        ModelDownloadService.cancel(this, model.id)
    }
}
