package com.worldscan.autoparts.ai

import android.content.Context
import android.net.Uri
import com.worldscan.autoparts.data.ModelInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.nehuatl.llamacpp.LlamaHelper
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Thin, app-specific wrapper around the `io.github.ljcamargo:llamacpp-kotlin`
 * library (pinned to version 0.4.0 in app/build.gradle.kts), which runs GGUF
 * models fully on-device via llama.cpp/JNI — no network calls, no server.
 *
 * This targets 0.4.0's documented API (see
 * https://github.com/ljcamargo/kotlinllamacpp):
 *   - LlamaHelper(contentResolver: ContentResolver, scope: CoroutineScope,
 *                  events: MutableSharedFlow<LlamaHelper.LLMEvent>)
 *   - fun load(path: String, contextLength: Int, mmprojPath: String? = null,
 *              onLoaded: (String) -> Unit)
 *   - fun predict(prompt: String) — fire-and-forget; results arrive as
 *     LLMEvent.Ongoing/Done/Error items on the shared flow passed into the
 *     constructor.
 *   - fun abort() / fun release()
 *
 * `path` accepts a `content://` or `file://` URI. Our GGUF files always live
 * in app-private internal storage (see ModelDownloadManager), so a plain
 * `Uri.fromFile(...)` is enough — no SAF / persistable-permission dance
 * needed (that's only required for user-picked files elsewhere on disk).
 *
 * This class exposes the same loadModel()/ask()/release() surface as before
 * so callers (ChatActivity) don't need to change.
 */
class LlamaInferenceManager(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val events = MutableSharedFlow<LlamaHelper.LLMEvent>(
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    private val helper = LlamaHelper(appContext.contentResolver, scope, events)

    private var loadedModelId: String? = null

    val isReady: Boolean get() = loadedModelId != null

    suspend fun loadModel(model: ModelInfo, contextLength: Int = 2048) {
        if (loadedModelId == model.id) return
        val file = File(File(appContext.filesDir, "ai_models"), model.fileName)
        val modelUri = Uri.fromFile(file).toString()

        suspendCancellableCoroutine<Unit> { cont ->
            lateinit var errorWatcher: Job
            errorWatcher = scope.launch {
                events.collect { event ->
                    if (event is LlamaHelper.LLMEvent.Error) {
                        if (cont.isActive) {
                            cont.resumeWithException(IllegalStateException("Model load failed: $event"))
                        }
                        errorWatcher.cancel()
                    }
                }
            }
            cont.invokeOnCancellation { errorWatcher.cancel() }
            helper.load(path = modelUri, contextLength = contextLength) { _ ->
                if (cont.isActive) cont.resume(Unit)
                errorWatcher.cancel()
            }
        }
        loadedModelId = model.id
    }

    /**
     * Runs one prompt through the model. [onToken] is invoked (on the main
     * thread, safe to touch views directly) with the accumulated
     * answer-so-far every time the model emits a new chunk — real
     * per-token streaming. Returns the full finished answer once generation
     * completes.
     */
    suspend fun ask(prompt: String, onToken: (String) -> Unit): String =
        suspendCancellableCoroutine { cont ->
            val sb = StringBuilder()
            lateinit var job: Job
            job = scope.launch {
                events.collect { event ->
                    when (event) {
                        is LlamaHelper.LLMEvent.Ongoing -> {
                            sb.append(event.word)
                            withContext(Dispatchers.Main) { onToken(sb.toString()) }
                        }
                        is LlamaHelper.LLMEvent.Done -> {
                            if (cont.isActive) cont.resume(sb.toString())
                            job.cancel()
                        }
                        is LlamaHelper.LLMEvent.Error -> {
                            if (cont.isActive) {
                                cont.resumeWithException(IllegalStateException("Inference failed: $event"))
                            }
                            job.cancel()
                        }
                        else -> Unit
                    }
                }
            }
            cont.invokeOnCancellation { job.cancel() }
            helper.predict(prompt)
        }

    fun release() {
        runCatching { helper.abort() }
        runCatching { helper.release() }
    }
}
