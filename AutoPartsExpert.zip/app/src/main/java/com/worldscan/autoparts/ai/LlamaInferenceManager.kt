package com.worldscan.autoparts.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.worldscan.autoparts.data.ModelInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.withContext
import org.nehuatl.llamacpp.LlamaHelper
import java.io.File

/**
 * Thin, app-specific wrapper around the `io.github.ljcamargo:llamacpp-kotlin`
 * library (pinned to version 0.1.2 in app/build.gradle.kts), which runs GGUF
 * models fully on-device via llama.cpp/JNI — no network calls, no server.
 *
 * IMPORTANT: this version's real API was confirmed directly from a Codemagic
 * compile-error log, NOT from the library's current GitHub README (which
 * documents a newer, unpublished 0.4.0 API with a ContentResolver + Flow of
 * LLMEvent). The actual 0.1.2 API is a simpler, direct suspend-function
 * shape:
 *   - LlamaHelper(scope: CoroutineScope)
 *   - suspend fun load(path: String, contextLength: Int)
 *   - suspend fun predict(prompt: String, partialCompletion: (String) -> Unit): String
 *   - fun abort() / fun release()
 * If a future bump of this dependency restores the richer 0.4.0-style API,
 * this file is the only place that needs to change.
 */
class LlamaInferenceManager(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val helper = LlamaHelper(scope)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var loadedModelId: String? = null

    val isReady: Boolean get() = loadedModelId != null

    suspend fun loadModel(model: ModelInfo, contextLength: Int = 2048) {
        if (loadedModelId == model.id) return
        val file = File(File(appContext.filesDir, "ai_models"), model.fileName)
        withContext(Dispatchers.IO) {
            helper.load(file.absolutePath, contextLength)
        }
        loadedModelId = model.id
    }

    /**
     * Runs one prompt through the model and returns the full generated
     * answer once complete. [onToken] is invoked with the growing partial
     * text so the UI can stream the reply live.
     *
     * `predict()`'s own callback may fire on a background/native thread, so
     * [onToken] is posted to the main thread via a Handler (non-blocking —
     * safe even if the callback happens to already be on Main, unlike
     * runBlocking which could deadlock in that case).
     */
    suspend fun ask(prompt: String, onToken: (String) -> Unit): String =
        withContext(Dispatchers.IO) {
            helper.predict(prompt) { partial ->
                mainHandler.post { onToken(partial) }
            }
        }

    fun release() {
        runCatching { helper.abort() }
        runCatching { helper.release() }
    }
}
