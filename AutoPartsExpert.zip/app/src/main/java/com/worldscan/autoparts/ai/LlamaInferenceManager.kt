package com.worldscan.autoparts.ai

import android.content.Context
import android.net.Uri
import com.worldscan.autoparts.data.ModelInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.onSubscription
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.nehuatl.llamacpp.LlamaHelper
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Thin, app-specific wrapper around the `io.github.ljcamargo:llamacpp-kotlin`
 * library, which runs GGUF models fully on-device via llama.cpp/JNI — no
 * network calls, no server. One instance is meant to live for as long as a
 * chat screen is open: call [loadModel] once, then [ask] per user turn.
 */
class LlamaInferenceManager(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val events = MutableSharedFlow<LlamaHelper.LLMEvent>(
        replay = 0,
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    private val helper = LlamaHelper(appContext.contentResolver, scope, events)

    private var loadedModelId: String? = null

    val isReady: Boolean get() = loadedModelId != null

    suspend fun loadModel(model: ModelInfo, contextLength: Int = 2048) {
        if (loadedModelId == model.id) return
        val file = File(File(appContext.filesDir, "ai_models"), model.fileName)
        val uri = Uri.fromFile(file).toString()
        suspendCancellableCoroutine<Unit> { cont ->
            try {
                helper.load(path = uri, contextLength = contextLength) {
                    if (cont.isActive) cont.resume(Unit)
                }
            } catch (t: Throwable) {
                if (cont.isActive) cont.resumeWithException(t)
            }
        }
        loadedModelId = model.id
    }

    /**
     * Runs one prompt through the model and returns the full generated
     * answer once complete. [onToken] is invoked with the growing partial
     * text so the UI can stream the reply live, word by word.
     *
     * Uses `onSubscription` so `predict()` only fires once the flow
     * collector is actually attached — otherwise the first tokens could be
     * emitted before anyone is listening and would be silently dropped.
     *
     * The collector runs on [scope] (IO), not the caller's scope, so
     * [onToken] is hopped onto Dispatchers.Main before being invoked —
     * callers update views directly from it.
     */
    suspend fun ask(prompt: String, onToken: (String) -> Unit): String =
        suspendCancellableCoroutine { cont ->
            val builder = StringBuilder()
            val job = scope.launch {
                events
                    .onSubscription { helper.predict(prompt) }
                    .collect { event ->
                        when (event) {
                            is LlamaHelper.LLMEvent.Ongoing -> {
                                builder.append(event.word)
                                val snapshot = builder.toString()
                                withContext(Dispatchers.Main) { onToken(snapshot) }
                            }
                            is LlamaHelper.LLMEvent.Done -> {
                                helper.stopPrediction()
                                if (cont.isActive) cont.resume(builder.toString())
                                cancel()
                            }
                            is LlamaHelper.LLMEvent.Error -> {
                                helper.stopPrediction()
                                if (cont.isActive) {
                                    cont.resumeWithException(IllegalStateException("Model inference failed"))
                                }
                                cancel()
                            }
                            else -> Unit
                        }
                    }
            }
            cont.invokeOnCancellation { job.cancel() }
        }

    fun release() {
        runCatching { helper.abort() }
        runCatching { helper.release() }
    }
}
