package com.worldscan.autoparts.ai

import android.content.Context
import com.worldscan.autoparts.data.ModelInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.withContext
import org.nehuatl.llamacpp.LlamaHelper
import java.io.File

/**
 * Thin, app-specific wrapper around the `io.github.ljcamargo:llamacpp-kotlin`
 * library (pinned to version 0.1.2 in app/build.gradle.kts), which runs GGUF
 * models fully on-device via llama.cpp/JNI — no network calls, no server.
 *
 * IMPORTANT: this version's real API was confirmed directly from two rounds
 * of Codemagic compile-error logs, NOT from the library's current GitHub
 * README (which documents a newer, unpublished 0.4.0 API). The confirmed
 * 0.1.2 API is:
 *   - LlamaHelper(scope: CoroutineScope)
 *   - suspend fun load(path: String, contextLength: Int)
 *   - suspend fun predict(prompt: String, partialCompletion: Boolean): String
 *   - fun abort() / fun release()
 * `predict`'s second parameter is a plain Boolean flag (its name is
 * misleading — it is NOT a token-streaming callback), and the function
 * returns only the finished answer as one String. This version of the
 * library exposes no per-token streaming hook, so the chat UI receives the
 * full answer in a single update rather than word-by-word — a cosmetic
 * difference only; nothing here should affect whether the app compiles or
 * whether answers are correct.
 */
class LlamaInferenceManager(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val helper = LlamaHelper(scope)

    private var loadedModelId: String? = null

    val isReady: Boolean get() = loadedModelId != null

    suspend fun loadModel(model: ModelInfo, contextLength: Int = 2048) {
        if (loadedModelId == model.id) return
        val file = File(File(appContext.filesDir, "ai_models"), model.fileName)
        withContext(Dispatchers.IO) {
            helper.load(file.absolutePath, contextLength)
        }
        loadedModelId = model.id
    }

    /**
     * Runs one prompt through the model and returns the full generated
     * answer once complete. [onToken] is invoked once with the finished
     * text (see class doc — this library version has no real streaming
     * hook), on whichever dispatcher the caller used, so it is safe to
     * touch views directly from it.
     */
    suspend fun ask(prompt: String, onToken: (String) -> Unit): String {
        val result = withContext(Dispatchers.IO) {
            helper.predict(prompt, true)
        }
        onToken(result)
        return result
    }

    fun release() {
        runCatching { helper.abort() }
        runCatching { helper.release() }
    }
}
