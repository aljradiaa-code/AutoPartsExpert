package com.worldscan.autoparts.data

import android.os.Handler
import android.os.Looper
import com.worldscan.autoparts.model.Part
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class PartRepository(private val database: AppDatabaseHelper) {
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    fun search(
        query: String,
        brand: String?,
        callback: (Result<SearchResult>) -> Unit
    ) {
        executor.execute {
            val startedAt = System.currentTimeMillis()
            runCatching {
                val parts = database.searchParts(query, brand)
                val duration = System.currentTimeMillis() - startedAt
                database.logSearch(query, parts.size, duration)
                SearchResult(parts, duration)
            }.also { result ->
                mainHandler.post { callback(result) }
            }
        }
    }

    fun loadMetadata(callback: (partCount: Int, recentSearches: List<String>) -> Unit) {
        executor.execute {
            val count = database.getPartCount()
            val recent = database.getRecentSearches()
            mainHandler.post { callback(count, recent) }
        }
    }

    fun shutdown() {
        executor.shutdownNow()
    }

    data class SearchResult(
        val parts: List<Part>,
        val durationMs: Long
    )
}
