package com.worldscan.autoparts.util

import org.junit.Assert.assertEquals
import org.junit.Test

class OemNormalizerTest {
    @Test
    fun removesDashesSpacesAndSymbols() {
        assertEquals("2630035505", OemNormalizer.normalize("26300-35505"))
        assertEquals("ABC123", OemNormalizer.normalize(" ab-c 123 "))
        assertEquals("2020", OemNormalizer.normalize("فلتر 2020"))
    }
}
