package com.worldscan.autoparts.util

import org.junit.Assert.assertEquals
import org.junit.Test

class TextNormalizerTest {
    @Test
    fun normalizesArabicAlefAndDiacritics() {
        assertEquals("النترا", TextNormalizer.normalizeForSearch("إلنترا"))
        assertEquals("هيونداي", TextNormalizer.normalizeForSearch("هِيُونْدَاي"))
    }
}
