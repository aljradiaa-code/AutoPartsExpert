pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Fallback in case io.github.ljcamargo:llamacpp-kotlin is not (yet) mirrored on
        // Maven Central for your Gradle/AGP version — safe to keep even if unused.
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "AutoPartsExpert"
include(":app")
