# Validation Report

Validation performed on the generated Android Studio source project:

- All 12 XML files parsed successfully.
- All local `@string`, `@drawable`, and `@layout` references were checked.
- `parts_seed.json` parsed successfully with 10 demo parts.
- SQLite schema and search SQL were executed in an in-memory SQLite database.
- Search cases passed for:
  - Arabic spelling normalization (`إلنترا` / `النترا`).
  - OEM normalization with and without separators.
  - vehicle year inside a compatibility range.
  - Hyundai / Kia / Toyota filters.
  - model, description, and no-result searches.
- `OemNormalizer.kt` and `TextNormalizer.kt` compiled with the available Kotlin compiler.
- The included Gradle bootstrap JAR was tested against a local fake Gradle distribution.

## Limitation

A full Android APK build was not executed in the generation environment because the Android SDK platform and Maven dependencies were not available locally. Open the project in Android Studio, allow Gradle Sync to download dependencies, then run `assembleDebug` or press Run.
