# Implementation Notes

## Architecture

- `MainActivity`: UI orchestration and search debounce.
- `PartRepository`: background execution and main-thread callbacks.
- `AppDatabaseHelper`: SQLite schema, seed, search, and search log.
- `OemNormalizer` / `TextNormalizer`: deterministic normalization.
- `PartAdapter`: RecyclerView result rendering.
- `PartDetailsBottomSheet`: detailed result display.

## Search behavior

The query is normalized and split into up to eight tokens. Every token must match either:

- part number / normalized part number,
- part description,
- company/origin,
- category,
- vehicle brand/model/year/engine/position/notes.

Exact normalized OEM matches are ranked first, then OEM-prefix matches, then general text matches. Results are capped at 100 rows per request.

## Schema extensions from the SRS

Two internal columns were added for deterministic local search:

- `parts.search_text_normalized`
- `compatibility.search_text_normalized`

These fields are implementation details and do not replace the original displayed fields.
