This project contains a small compatible Gradle bootstrap JAR generated for the
package. It downloads and launches Gradle 8.13 using gradle-wrapper.properties.
After the first successful sync, it can be replaced with the official wrapper by
running: gradle wrapper --gradle-version 8.13
